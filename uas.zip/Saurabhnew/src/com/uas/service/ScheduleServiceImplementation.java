package com.uas.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Service;

import com.uas.bean.ProgramBean;
import com.uas.bean.ScheduleBean;
import com.uas.dao.IScheduleDAO;

@Service
public class ScheduleServiceImplementation implements IScheduleService{

	@Autowired
	private IScheduleDAO isd;
	
	@Override
	public int addScheduleDetails(ScheduleBean sb) {
		return isd.addScheduleDetails(sb);
	}

	@Override
	public ArrayList<ScheduleBean> viewAllScheduleDetails() {
		return isd.viewAllScheduleDetails();
	}

	@Override
	public int deleteScheduleDetails(int deleteScheduleId) {
		return isd.deleteScheduleDetails(deleteScheduleId);
	}

	@Override
	public ScheduleBean updateScheduleDetails(int scheId) {
		
		return isd.updateScheduleDetails(scheId);
	}

	



	@Override
	public int updateNewScheduleDetails(ScheduleBean usbo) {

		return isd.updateNewScheduleDetails(usbo);
		}

	@Override
	public ArrayList<ProgramBean> viewAllProName() {
		return isd.viewAllProName();
	}




	
	
}
