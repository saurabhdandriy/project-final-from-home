package com.uas.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.uas.bean.ProgramBean;
import com.uas.bean.ScheduleBean;

@Repository
@Transactional
public class ProgramDAOImplementation implements IProgramDAO
{


	
	
	@PersistenceContext 
	private EntityManager entitymanager;
	


	
	
	@Override
	public String addProgramDetails(ProgramBean pb) {
		entitymanager.persist(pb);
		return pb.getProgramName();	
	
	}
	
		
	
	@Override
	public int deleteProgramDetails(String deleteProgramName) {
		System.out.println("It is in program offered delete");
		Query deleteQuery=entitymanager.createQuery("delete ProgramBean where programName =:delProId");
		deleteQuery.setParameter("delProId",deleteProgramName);
		
		int result = deleteQuery.executeUpdate();
		return result;
	}



	

	@Override
	public ArrayList<ProgramBean> viewAllProgramDetails() {
		Query viewProgQuery = entitymanager.createNamedQuery("getAllPrograms");
		return (ArrayList<ProgramBean>) viewProgQuery.getResultList();
	}



	@Override
	public ProgramBean updateprogramDetails(String programName) {
		Query updateQuery = entitymanager.createQuery("select pb from ProgramBean pb where programName =:upproname ");
		updateQuery.setParameter("upproname", programName);
		ProgramBean upb = (ProgramBean) updateQuery.getSingleResult();
		return upb;

	}
	
	
	@Override
	public String updateNewProgramDetails(ProgramBean upbo) {
		entitymanager.merge(upbo);
		return upbo.getProgramName();
	}



	
	}






	
	


