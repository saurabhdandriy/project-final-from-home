package com.uas.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jboss.security.annotation.Authentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.uas.bean.Application;
import com.uas.bean.LoginBean;
import com.uas.bean.Participant;
import com.uas.bean.ProgramBean;
import com.uas.bean.ScheduleBean;
import com.uas.service.ILoginService;
import com.uas.service.IProgramService;
import com.uas.service.IScheduleService;
import com.uas.service.IStudentService;


@Controller
public class UASController 
{
	@Autowired
	private ILoginService  ilogin=null;
	@Autowired
	private IScheduleService iss;
	@Autowired
	private IProgramService ips;
	
	
	
	/**************************************HOME*****************************************************/
	
	@RequestMapping("/success")
	public String GetSuccessPage(){
		return "success";
	}

	@RequestMapping("/About")
	public String GetaboutPage(){
		return "About";
	}
	@RequestMapping("/campus")
	public String GetcampusPage(){
		return "campus";
	}
	@RequestMapping("/placement")
	public String GetplacementPage(){
		return "placement";
	}
	
	/*
	@RequestMapping("/ApplicationForm")
	public String GetApplicationPage(){
		
		return "ApplicationForm";
	}*/
	
	@RequestMapping("/MACapplication")
	public String GetmacApplicationPage(){
		return "MACapplication";
	}
	
	@RequestMapping("/uni")
	public String GetUniPage(){
		return "uni";
	}
	
	
	@RequestMapping(value="/updatebyId" ,method=RequestMethod.POST)
	public String GetUpdatePage(Model m){
		m.addAttribute("updatestudentObj",new Application());
		return "updatebyId";	}
	
	@RequestMapping("/home")
	public String getHomePage(){
		return "home";
	}

	@RequestMapping("/admin")
	public String getAdminPage(){
		return "admin";
	}
	
	/**********************************************LOGIN****************************************************/
	
	@RequestMapping("/login")
	public String getLoginPage(Model m)
	{
		m.addAttribute("loginObj",new LoginBean());
		return "login";
		
	}
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String doValidate(HttpSession session,Model m,@ModelAttribute("loginObj")LoginBean log)
	{
		 String path=null;
		 boolean res;
		 String usr=log.getUserName();
		 String pass=log.getPassword();
		
			if(res=ilogin.validateLoginDetails(usr,pass))
				{
				session.setAttribute("log",log);
					 path="admin";
				}
			else if(res=ilogin.validateLoginDetails2(usr,pass))
				{ 
				session.setAttribute("log",log);
				path="mac";
				}
			else
			{
				m.addAttribute("loginObj",new LoginBean());
				m.addAttribute("msg","Enter the correct Credentials");
				path="login";
			}
			return path;
		
	}
	

	@RequestMapping("/logout")
	public String logout(HttpSession session ) {
	    session.invalidate();
	    return "redirect:/logout.html";
	}
	
	//Application app=new Application();
	
	@RequestMapping("ApplicationForm")
	public String getHome(Model m){
		m.addAttribute("studentObj",new Application());
		return "ApplicationForm";
	}

	@Autowired
	private IStudentService serv;

	@RequestMapping(value="store",method=RequestMethod.POST)
	public String storeStudentDetails(Model m , @ModelAttribute("studentObj") Application rc){
		System.out.println("in adding method");
		String target = null;		
		int appid = serv.addStudentDetails(rc);
		System.out.println("rid taken"+ appid);
		if(appid>0)
		{
			m.addAttribute("studentObj",new Application());
			System.out.println("Cheking rid ");
			m.addAttribute("msg","You have been registered successfully");
			m.addAttribute("appid", appid);
			target="ApplicationForm";
		}
		else
		{
			m.addAttribute("studentObj",new Application());
			m.addAttribute("msg","You are  not registered successfully");
			target= "ApplicationForm";
		}
		
		return target;
	}

	@RequestMapping(value="viewAll")
	public ModelAndView viewAll(Model m, @ModelAttribute("applicantObj")Application ap){
		ModelAndView mv=new ModelAndView();
		ArrayList<Application> rlist=serv.getAllStudentInfo();
		mv.setViewName("viewAll");
		mv.addObject("data", rlist);
		return mv;
	}
	
	@RequestMapping("Participant")
	public String getHome2(Model m){
		m.addAttribute("participantObj",new Participant());

		return "Participant";
	}


	@RequestMapping(value="hello",method=RequestMethod.POST)
	public String storeParticipantDetails(Model m , @ModelAttribute("participantObj") Participant pc){
		System.out.println("in adding method");
		String target = null;
		
		
		int pid = serv.addParticipantDetails(pc);
		System.out.println("rid taken"+ pid);
		if(pid>0)
		{
			System.out.println("Cheking rid ");
			m.addAttribute("msg1","You have added details successfully");
			m.addAttribute("pid", pid);
			target="success1";
		}
		else
		{
			target= "Participant";
		}
		
		return target;
	}
	



	@RequestMapping(value="updateDetails",method=RequestMethod.POST)                                                          //Update Hotel
	public String update(Model m,@ModelAttribute("applicantObj") Application ap,@RequestParam("id") int id)
	{
		String target=null;
		ap.setApplicationId(id);
		int result=serv.updateStatusDetails(ap);
		if(result > 0)
		{
			m.addAttribute("msg","Status updated Successfully for");
			m.addAttribute("appId",ap.getApplicationId());
			target="updatestatussuccess";
		}
		else
		{
			target="home";
		}
		return target;

	}

	@RequestMapping("/status")
	public String getStatusPage(Model m)
	{
		m.addAttribute("statusObj",new Application());

		return "status";
		
	}

	@RequestMapping("status1")
	public ModelAndView viewStatus(Model m,@ModelAttribute("statusObj")Application  app){
		ModelAndView mv1=new ModelAndView();
		int id=app.getApplicationId();
		ArrayList<Application> rlist1=serv.getAllStatus(id);
		mv1.setViewName("status1");
		mv1.addObject("data1", rlist1);
		return mv1;
	}
	@RequestMapping(value="ViewInterview")
	public ModelAndView viewInterviewList()
	{
		ModelAndView mv=new ModelAndView();
		ArrayList<Application> rlist=serv.viewInterviewList();
		mv.setViewName("ViewInterview");
		mv.addObject("dataInter", rlist);
		return mv;
	}	
	

/**************************************Admin*********************************************************/
	
	
	@RequestMapping("admin")
	public String goAdminPage()
	{
		return "admin";
	}
	
	/***************************************programs**********************************************/
	
	@RequestMapping("program")
	public String goProgramPage()
	{
		return "program";
	}

	@RequestMapping("addprogramdetails")
	public String goaddprogramPage(Model m)
	{
		m.addAttribute("programObj",new ProgramBean());
		
		return "addprogramdetails";
	}

	
	
	
	@RequestMapping(value="addprogramsuccess",method=RequestMethod.POST)
	public String addprogramDetailsPage(Model m,@ModelAttribute("programObj") ProgramBean pb)
	{
	String target=null;
		String progName;
		progName=ips.addProgramDetails(pb);
		if(progName != null)
		{
			m.addAttribute("programObj",new ProgramBean());
			m.addAttribute("msg","Program data added  successfully your program is...");
			m.addAttribute("programName", progName);
			target="addprogramdetails";
		}
		else
		{
			m.addAttribute("programObj",new ProgramBean());
			m.addAttribute("msg","Error occured while storing the data..");
			target="addprogramdetails";
		}
		return target;
	}
	

	@RequestMapping("deleteprogramdetails")
	public String goDeleteProgramPage(Model m)
	{
		m.addAttribute("programObj",new ProgramBean());
		return "deleteprogramdetails";
	}
	
	@RequestMapping(value="deleteprogramsuccess",method=RequestMethod.POST)
	public String deleteProgramDetailsPage(Model m,@ModelAttribute("programObj") ProgramBean pb)
	{
	String target=null;
		String deleteProgramName=pb.getProgramName();
		int result;
		result=ips.deleteProgramDetails(deleteProgramName);
		if(result > 0)
		{
			m.addAttribute("programObj",new ProgramBean());
			m.addAttribute("msg","Rows deleted successfully");
			m.addAttribute("deleteProgramId", deleteProgramName);
			target="deleteprogramdetails";
		}
		else
		{
			m.addAttribute("programObj",new ProgramBean());
			m.addAttribute("msg","Error occured rows are not deleted");
			target="deleteprogramdetails";
		}
		return target;
	}
	
	
	@RequestMapping("viewprogramdetails")
	public ModelAndView viewAllProgram()
	{
		ModelAndView mv= new ModelAndView();
		ArrayList<ProgramBean> proglist= ips.viewAllProgramDetails();
		mv.setViewName("viewprogsuccess");
		mv.addObject("progdata",proglist);
		return mv;
	}
	

	@RequestMapping("updateprogramdetails")
	public String goUpdateProgramPage(Model m)
	{
		m.addAttribute("programObj", new ProgramBean());
		return "updateprogramdetails";
	}
	
	
	


@RequestMapping(value="updatenewprogramdetails",method=RequestMethod.POST)
public String updateScheduleDetailsPage(Model m,@ModelAttribute("programObj") ProgramBean pb)
{
	String target=null;
	String programName=pb.getProgramName();
	ProgramBean result=ips.updateProgramDetails(programName);
	
	if(result!=null)
	{
		
		m.addAttribute("updatelist",result);
		target="updatenewprogramdetails";	
	}
	else
	{
		m.addAttribute("error","Something went wrong!! please try again");
		target="error";
		
	}
	return target;
}


@RequestMapping(value="updateprogramsuccess",method=RequestMethod.POST)
public String updateScheduleDetailssuccessPage(Model m,@ModelAttribute("programObj") ProgramBean upbo)
{
String target=null;
	
	String result=ips.updateNewProgramDetails(upbo);
	if(result!=null)
	{
		m.addAttribute("msg","programs data updated  successfully The schedule id is...");
		m.addAttribute("programName",result);
		target="updateprogramsuccess";
	}
	else
	{
		m.addAttribute("error","Something went wrong!! please try again");
		target="error";
	}
	return target;
}


/****************************************************schedules*************************************************/
	
	
	@RequestMapping("schedule")
	public String goSchedulePage()
	{
		return "schedule";
	}

	@RequestMapping("addscheduledetails")
	public String goAddSchedulePage(Model m)
	{
		System.out.println("The value is retrieved");
		ArrayList<ProgramBean> prolist = iss.viewAllProName();
		
		m.addAttribute("scheduleObj",new ScheduleBean());
		m.addAttribute("programName",prolist);
		return "addscheduledetails";
	}
	
	
	@RequestMapping(value="addsuccess",method=RequestMethod.POST)
	public String addScheduleDetailsPage(Model m,@ModelAttribute("scheduleObj") ScheduleBean sb)
	{
		System.out.println("Inside add success controller");
		String target=null;
		int sid;
		sid=iss.addScheduleDetails(sb);
		System.out.println("Value is retrieved");
		if(sid>0)
		{
			m.addAttribute("scheduleObj",new ScheduleBean());
			m.addAttribute("msg","schedule data added  successfully The schedule id is...");
			m.addAttribute("scheduleId", sid);
			System.out.println("inside the controller end!!");
			target="addscheduledetails";
		}
		else
		{
			m.addAttribute("msg","Error!! Occured");
			target="addscheduledetails";
		}
		return target;
	}
	
	
	@RequestMapping("deletescheduledetails")
	public String goDeleteSchedulePage(Model m)
	{
		m.addAttribute("scheduleObj",new ScheduleBean());
		return "deletescheduledetails";
	}

@RequestMapping(value="deletesuccess",method=RequestMethod.POST)
public String deleScheduleDetailsPage(Model m,@ModelAttribute("scheduleObj") ScheduleBean sb)
{
String target=null;
	int deleteScheduleId=sb.getScheduleProgramId();
	int result;
	result=iss.deleteScheduleDetails(deleteScheduleId);
	if(result>0)
	{
		m.addAttribute("scheduleObj",new ScheduleBean());
		m.addAttribute("msg","Rows deleted successfully");
		m.addAttribute("deleteid", deleteScheduleId);
		target="deletescheduledetails";
	}
	else
	{
		m.addAttribute("scheduleObj",new ScheduleBean());
		target="deletescheduledetails";
	}
	return target;
}



	@RequestMapping("viewscheduledetails")
	public ModelAndView viewAll()
	{
		ModelAndView mv= new ModelAndView();
		ArrayList<ScheduleBean> schelist= iss.viewAllScheduleDetails();
		mv.setViewName("viewsuccess");
		mv.addObject("sechdata",schelist);
		return mv;
	}



@RequestMapping("updatescheduledetails")
public String goUpdateSchedulePage(Model m)

{
	System.out.println("upadte 1");
	m.addAttribute("scheduleObj", new ScheduleBean());
	return "updatescheduledetails";
}

@RequestMapping(value="updatenewscheduledetails",method=RequestMethod.POST)
public String updateScheduleDetailsPage(Model m,@ModelAttribute("scheduleObj") ScheduleBean sb)
{
	String target=null;
	int scheId=sb.getScheduleProgramId();
	ScheduleBean result=iss.updateScheduleDetails(scheId);
	if(result!=null)
	{
		
		m.addAttribute("updatelist",result);
		target="updatenewscheduledetails";	
	}
	else
	{
		m.addAttribute("error","Something went wrong!! please try again");
		target="error";
		
	}
	return target;
}

@RequestMapping(value="updateschedulesuccess",method=RequestMethod.POST)
public String updateScheduleDetailssuccessPage(Model m,@ModelAttribute("scheduleObj") ScheduleBean usbo)
{
String target=null;
	
	int result=iss.updateNewScheduleDetails(usbo);
	if(result>0)
	{
		m.addAttribute("msg","schedule data updated  successfully The schedule id is...");
		m.addAttribute("scheduleId",result);
		target="updateschedulesuccess";
	}
	else
	{
		m.addAttribute("error","Something went wrong!! please try again");
		target="error";
	}
	return target;
}



}


	
	






	
	
	


